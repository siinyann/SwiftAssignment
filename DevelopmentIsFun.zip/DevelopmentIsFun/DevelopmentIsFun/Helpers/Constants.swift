//
//  Constants.swift
//  DevelopmentIsFun
//
//  Created by Swift on 6/4/22.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        // Transition to Tar Bar Controller to the home page
        static let homeViewController = "TabBarController"
    }
}
